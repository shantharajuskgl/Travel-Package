package com.TravelPackage.Repository;

import org.springframework.data.repository.CrudRepository;

import com.TravelPackage.Entity.TravelPackage;

public interface TravelPackageRepository extends CrudRepository<TravelPackage, Integer> {

}
