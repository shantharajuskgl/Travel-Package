package com.TravelPackage;

public enum Passengertype {
	STANDARD,
    GOLD,
    PREMIUM

}
